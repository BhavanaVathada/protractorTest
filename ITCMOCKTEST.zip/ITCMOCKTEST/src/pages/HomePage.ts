import {$,ElementFinder,element,by} from "protractor"

export class HomePageObjects {
    public emailInput: ElementFinder;
    public Password:ElementFinder;
    public SignIn:ElementFinder;
    public Pageheading:ElementFinder;
    public submitButton:ElementFinder;
    public emailCreate:ElementFinder;
    public submitCreate:ElementFinder;
    public errorMsg:ElementFinder;
    public signOut:ElementFinder;
    public womenPage:ElementFinder;
    public dressPage:ElementFinder;
    public TshirtsPage:ElementFinder;
    public errAuthentication:ElementFinder;
    public womenPagetitle:ElementFinder;
    public womenPageSub1:ElementFinder;
    public womenPageSub2:ElementFinder;
    public searchBar:ElementFinder;
    public searchButton:ElementFinder;
    public searchResultsNo:ElementFinder;

    constructor(){
        this.emailInput = element(by.xpath("(//input[@name='email'])[1]"))
        this.Password=element(by.xpath("//input[@name='passwd']"))
        this.SignIn = element(by.xpath("//*[@class='login']"))
        this.Pageheading=element(by.xpath("//*[@class='page-heading']"))
        this.submitButton=element(by.xpath("//button[@name='SubmitLogin']"))
        this.emailCreate=element(by.xpath("//*[@name='email_create']"))
        this.submitCreate=element(by.xpath("//*[@id='SubmitCreate']"))
        this.errorMsg=element(by.xpath("//*[@id='create_account_error']"))
        this.signOut=element(by.xpath("//*[@class='logout']"))
        this.womenPage=element(by.xpath("(//*[@title='Women'])[1]"))
        this.dressPage=element(by.xpath("(//*[@title='Dresses'])[1]"))
        this.TshirtsPage=element(by.xpath("(//*[@title='T-shirts'])[1]"))
        this.errAuthentication=element(by.xpath("(//*[@class='alert alert-danger'])[1]/p"))
        this.womenPagetitle=element(by.xpath("//div[@id='categories_block_left']/h2"))
        this.womenPageSub1=element(by.xpath("(//div[@id='categories_block_left']/div/ul/li)[1]"))
        this.womenPageSub2=element(by.xpath("(//div[@id='categories_block_left']/div/ul/li)[2]"))
    this.searchBar=element(by.xpath("//input[@id='search_query_top']"))
    this.searchButton=element(by.xpath("//button[@name='submit_search']"))
    this.searchResultsNo=element(by.xpath("//*[@class='heading-counter']"))
    }
}