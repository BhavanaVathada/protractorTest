
import{HomePageObjects} from "../pages/HomePage";
import{protractor,ExpectedConditions,ElementFinder} from 'protractor'
const chai = require("chai").use(require("chai-as-promised"));
const{when,Then,Given}= require("cucumber")
const expect = chai.expect;
const HomePageops:HomePageObjects = new HomePageObjects();
const { browser, element, by, then } = require("protractor")
import { delay, async, all, timeout } from "q";
import { connect } from "net";



var EC = protractor.ExpectedConditions;

Given('Open the Application.',{timeout: 60 *10000}, async ()=>{

    await browser.get("http://automationpractice.com/index.php");
    //Validating the Page Title
    return await expect(browser.getTitle()).to.eventually.equal('My Store')

});

Then('Click on SignIn Button.',{timeout: 60 *10000}, async ()=>{

   
    browser.wait(EC.visibilityOf(HomePageops.SignIn), 80000);
    console.log("HomePage Validated")
    // Click on signin
    await HomePageops.SignIn.click();
    console.log('Signed In')
    return await expect(HomePageops.Pageheading.getText()).to.eventually.equal('AUTHENTICATION')

});

Then ('Enter valid user name and password',{timeout:60*10000}, async()=>{

    await HomePageops.emailInput.sendKeys("test_mocktest@gmail.com");
    await HomePageops.Password.sendKeys("september");
    browser.sleep(2000);
    await HomePageops.submitButton.click();
    browser.wait(EC.visibilityOf(HomePageops.Pageheading), 80000);
    console.log("Launching My Account")
    return await expect(HomePageops.Pageheading.getText()).to.eventually.equal('MY ACCOUNT')

});
Then ('Signout',{timeout:60*10000}, async()=>{

    browser.sleep(3000)
    await HomePageops.signOut.click();
    browser.sleep(3000)
    console.log("Signing Out")
    return await expect(HomePageops.Pageheading.getText()).to.eventually.equal('AUTHENTICATION')

});


Then ('Hit Enter leaving email field blank',{timeout:60*10000}, async()=>{

    await HomePageops.emailCreate.sendKeys(" ");
    browser.sleep(2000);
    await HomePageops.submitCreate.click();
    browser.wait(EC.visibilityOf(HomePageops.errorMsg), 80000);
    //Validate the error message
    console.log("Error Message Displayed")
    return await expect(HomePageops.errorMsg.getText()).to.eventually.equal('Invalid email address.')

});


Then (/^Validate all \"(.*)\" in Shopping Section$/,{timeout:60*10000}, async(Options: string) => {


    if(Options == "WOMEN")
    {
 return await HomePageops.womenPage.click();
 //console.log("WOMEN PAGE")
    }
    if(Options =="DRESSES")
    {
    return await HomePageops.dressPage.click();
    //console.log("Dress PAGE")
}
if(Options =="T- Shirts")
    {
    return await HomePageops.TshirtsPage.click();
    //console.log("T Shirts PAGE")   
}
   
});


Then ('Try to login with Invalid Username and Password',{timeout:60*10000}, async() => {

    await HomePageops.emailInput.sendKeys("test_mocktest@gmail.com");
    //Enter wrong Pwd
    await HomePageops.Password.sendKeys("september2");
    browser.sleep(3000);
    await HomePageops.submitButton.click();
    browser.sleep(2000);
    console.log("Launching My Account - Invalid deatils")
    return await expect(HomePageops.errAuthentication.getText()).to.eventually.equal('There is 1 error')
});


Then (/^Validate all \"(.*)\" in Shopping Section$/,{timeout:60*10000}, async(Options: string) => {


    if(Options == "WOMEN")
    {
 return await HomePageops.womenPage.click();
 //console.log("WOMEN PAGE")
    }
    if(Options =="DRESSES")
    {
    return await HomePageops.dressPage.click();
    //console.log("Dress PAGE")
}
if(Options =="T- Shirts")
    {
    return await HomePageops.TshirtsPage.click();
    //console.log("T Shirts PAGE")   
}
   
});

Then ('Validate all Women section in Shopping Section',{timeout:60*10000}, async() => {


 await HomePageops.womenPage.click();
 console.log("Women Page")
 return await expect(HomePageops.womenPagetitle.getText()).to.eventually.equal('WOMEN')
});

Then ('Validate Women section sub categories',{timeout:60*10000}, async() => {
    //Validating Page Sub title
    console.log("Validating Sub Categories - Women Page")
    await expect(HomePageops.womenPageSub1.getText()).to.eventually.equal('Tops')
    return await expect(HomePageops.womenPageSub2.getText()).to.eventually.equal('Dresses')   
   });

   Then ('Validate Search Bar.',{timeout:60*10000}, async() => {
   
    console.log("Validate Search Bar")
    await HomePageops.searchBar.sendKeys("printed")
    await HomePageops.searchButton.click()
    browser.sleep(1000)
    console.log("Validating Search Results")
    return await expect(HomePageops.searchResultsNo.getText()).to.eventually.equal('5 results have been found.')
   });

   
