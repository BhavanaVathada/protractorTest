//import { Reporter } from "support/reporter";
var reporter = require('cucumber-html-reporter');
const jsonReports = process.cwd() + "/reports/json";
var path = require('path');
//let downloadsPath = path.resolve(__dirname, './TestDownload');
var endDt, startDt;

exports.config = {
  allScriptsTimeout: 110000,
  getPageTimeout: 110000,
  SELENIUM_PROMISE_MANAGER: true,
  directConnect: true,
 
 
  closeBrowserOnExit: false,
  ignoreUncaughtExceptions: true,
  specs: [
    'features/*.feature'
  ],
  cucumberOpts: {
    compiler: "ts:ts-node",
    require: [
      'acpt-steps/*.ts'
    ],

    strict: true,
    //format: 'json:results/results.json',
    tags:"@testsuite",
    defaultTimeoutInterval: 900000
  },


  onPrepare: function () {
    browser.manage().window().maximize(); // maximize the browser before executing the feature files
    browser.manage().timeouts().implicitlyWait(8000);
    browser.ignoreSynchronization = true;

  },

  capabilities: {
    browserName: "chrome",
    //handlesAlerts:true,'
    //unexpectedAlertBehaviour:"SKIP",?
    chromeOptions: {
      args: ['--disable-web-security']
    }, 

  },

  baseUrl: "http://automationpractice.com/index.php",
  //seleniumAddress: "http://localhost:4444/wd/hub/",
 // seleniumServerJar: "./../../node_modules/selenium-server-standalone-jar/jar/selenium-server-standalone-3.141.5.jar",
  
  framework: "custom",
  frameworkPath: require.resolve("protractor-cucumber-framework"),

  useAllAngular2AppRoots: true,

  beforeLaunch: function () {
    require('ts-node').register({

    });
  },

  /*
  onComplete: function () {
    endDt = new Date();
    var difference = (endDt - startDt) / 1000;
    var days = Math.floor(difference / (3600 * 24));
    var hours = Math.floor((difference - (days * (3600 * 24))) / 3600);
    var minutes = Math.floor((difference - (days * (3600 * 24)) - (hours * 3600)) / 60);
    var seconds = Math.floor(difference - (days * (3600 * 24)) - (hours * 3600) - (minutes * 60));
    if (hours < 10) { hours = "0" + hours; }
    if (minutes < 10) { minutes = "0" + minutes; }
    if (seconds < 10) { seconds = "0" + seconds; }

    //console.log('Total time duration ============ >> '+ days+':'+ hours+':'+minutes+':'+seconds);

    var options = {
      theme: 'bootstrap', //[Themes can be added more 'bootstrap', 'foundation', 'simple']
      jsonFile: 'results/results.json',
      output: 'Reports/test_report.html',
      reportSuiteAsScenarios: true,
      overviewReport: true,
      launchReport: true,

      brandTitle: 'Test Report',
      metadata: {
        "Application Version:": "0.0.1",
        "Environment": "stg",
        "Browser": "Chrome  62.0.3163.79",
        //"Duration": hours + " hr "+ minutes +" m " + seconds +" s" ,
        //"Start Date": startDt,
        "Date": endDt
      }
    };
    reporter.generate(options);


  },

*/



};